#include <conio.h>
#include <stdio.h>

int main()
{
    printf( "Hola mundo" );

    getch(); /* Pausa */

    return 0;
}
